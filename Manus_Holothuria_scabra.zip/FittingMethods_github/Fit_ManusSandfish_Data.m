% function Fit_Example_Data()
clear all

%% ======================== DATA INPUTS ========================

% What are the site names?
[SiteNames] = textread('ManusSandfish_SiteNames.csv','%s%*[^\n]')

% First, read in the parentage matrix. Each row corresponds to a source reef containing
% sampled parents. Each column corresponds to a destination reef containing sampled
% juveniles. The elements in each cell indicate the number of assigned juveniles on the
% COLUMN reef whose parents were on the ROW reef. The final row contains the unassigned
% juveniles sampled on each COLUMN reef.
Assignments = csvread('ManusSandfish_parentage_matrix_new.csv');

% Second, read in the proportion of adults on each reef that were sampled. This vector
% should have the number of rows equal to the number of columns in the "Obs" matrix.
% That is - the number of sampled reefs.
Adult_sample_proportions = csvread('ManusSandfish_proportion_sampled.csv');

% Third, read in a distance matrix showing the distances between all
% Distances = csvread('Example_distance_matrix.csv');

Locations = [147.1417   -2.2194
  147.2804   -2.1632
  146.9595   -2.2236
  146.8261   -2.2088
  146.8303   -2.3983];
Distances = squareform(pdist(Locations))*110;

% Fourth, read in a distance matrix showing the distances between all
Reef_sizes = csvread('ManusSandfish_patch_size_matrix.csv');

% Fifth, read in a list of the reefs that were sampled
Sampled_reefs = csvread('ManusSandfish_sampled_patch_list.csv');

% Sixth, read in the locations of each of the reefs
Centroids = csvread('ManusSandfish_patch_location.csv');

%% =============================================================

% How many reefs were sampled
Num_sampled_reefs = size(Assignments,2);
Num_reefs = size(Centroids,1);

% Define the generalised Gaussian functions that we're fitting here
F  = @(x,k,theta)    exp(k).*theta.*exp(-(exp(k)*x).^theta)/gamma(1/theta);
FM = @(x,k,theta) x.*exp(k).*theta.*exp(-(exp(k)*x).^theta)/gamma(1/theta);

% Run through the list of potential kernels and fit each one to the data
Theta_list = [1 2 3 0.5];
LowerBound = -30;
UpperBound = 10;
for th = 1:length(Theta_list);
    [Best_k(th),LL_k(th)] = fminbnd(@Kernel_Fitting_Function,LowerBound,UpperBound,[],... % These are the search input parameters
        Assignments,Distances,Reef_sizes,Sampled_reefs,Adult_sample_proportions,F,Theta_list(th)); % These are the extra parameters needed by the function
end

% Identify the best fit from the candidate kernels
[~,Best_kernel] = min(LL_k)
Best_fit_k = Best_k(Best_kernel)

% Create bootstrap confidence bounds around the best estimate by re-sampling at the patch scale
for b = 1:500

    % First resample the assignment data, as well as the proportion of each reef sampled
    Bootstrap_resample = randsample(Num_sampled_reefs,Num_sampled_reefs,1);
    Sampled_reefs_b = Sampled_reefs(Bootstrap_resample);
    Adult_sample_proportions_b = Adult_sample_proportions(Bootstrap_resample);
    Assignments_b = [Assignments(Bootstrap_resample,Bootstrap_resample); Assignments(end,Bootstrap_resample)];
    Distances_b = Distances(Bootstrap_resample,Bootstrap_resample);
    Reef_sizes_b = Reef_sizes(Bootstrap_resample);

    % Re-fit the kernel of the correct shape to this data
    [Bootstrap_k(b),LL_b] = fminbnd(@Kernel_Fitting_Function,LowerBound,UpperBound,[],... % These are the search input parameters
        Assignments_b,Distances_b,Reef_sizes_b,Sampled_reefs_b,Adult_sample_proportions_b,F,Theta_list(Best_kernel)); % These are the extra parameters needed by the function

end
save OUTPUTS

clear all; load OUTPUTS
xx = linspace(0,max(Distances(:))*10,1000);

% Ignore all the LB and UB solutions
Bootstrap_k(Bootstrap_k < LowerBound+1) = [];
Bootstrap_k(Bootstrap_k > UpperBound-1) = [];
Confidence_bounds = quantile(Bootstrap_k,[0.16 0.5 0.84]);

K1 = F(xx,Confidence_bounds(1),Theta_list(Best_kernel)); K1 = K1./K1(1);
K2 = F(xx,Confidence_bounds(3),Theta_list(Best_kernel)); K2 = K2./K2(1);
KD = F(xx,Confidence_bounds(2),Theta_list(Best_kernel)); KD = KD./KD(1);
KM = F(xx,Best_k(Best_kernel),Theta_list(Best_kernel)); KM = KM./KM(1);

figure(1), clf, hold on, box on; CL = get(gca,'colororder'); FS = 15;
set(gca,'ytick',[0:0.25:1],'yticklabel',0:25:100,'fontsize',FS)

CS = cumsum(KM); CS = CS./CS(end);
F_50 = min(find(CS > 0.5));
F_95 = min(find(CS > 0.95));
xx([F_50,F_95])
KM = KM./KM(1); 

pp1 = patch([xx([1:F_50 F_50]) 0],[KM(1:F_50) 0 0],'k');
set(pp1,'facealpha',0.4,'edgecolor','none');
% pp2 = patch(xx([F_50:F_95 F_95 F_50]),[KM(F_50:F_95) 0 0],'k');
% set(pp2,'facealpha',0.2,'edgecolor','none');

pp3 = plot(xx,KM,'-','color','k','linewidth',2);
pp4 = plot(xx,K1,'--','color','k','linewidth',1);
plot(xx,K2,'--','color','k','linewidth',1)

xlabel('Distance (km)','fontsize',FS+4)
ylabel({'Dispersal strength','(\% of local retention)'},'fontsize',FS+4)
xlim([0 100])

L = legend([pp3,pp4,pp1],'Best fit kernel','$\pm 1$ SD','50\% of dispersal','fontsize',FS+4);
set(L,'box','off')

KM = KM./sum(KM);
disp(['Mean dispersal distance is ' num2str(round(KM*xx')) 'km'])

Make_TIFF('New_fit.tiff',[0 0 15 9]*1.5)

















